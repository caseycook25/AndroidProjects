package com.example.cook01.myapplication;

/**
 * Created by Cook01 on 4/19/2017.
 */

public class Constants {
    public static final String ACTION_ADD_ONE = "MYACTION.ADDONE";
    public static final String ACTION_ADD_TWO = "MYACTION.ADDTWO";
    public static final String ACTION_DEL_ONE = "MYACTION.DELONE";
    public static final String ACTION_MAKE_BREAKFAST = "MYACTION.MAKE";
}
